import { config as dotenvConfig } from 'dotenv';
dotenvConfig();
